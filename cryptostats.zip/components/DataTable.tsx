
import React from 'react';
import { DataSource, ListingEntry } from '../types';

interface Props {
  title: string;
  source: DataSource;
  data: ListingEntry[];
}

const DataTable: React.FC<Props> = ({ title, source, data }) => {
  return (
    <div className="bg-slate-800/40 border border-slate-700/50 rounded-xl overflow-hidden shadow-sm flex flex-col h-full">
      <div className="px-5 py-4 border-b border-slate-700 flex justify-between items-center">
        <h3 className="font-bold text-slate-200">{title}</h3>
        <span className="text-xs text-slate-500 mono">{data.length} records</span>
      </div>
      <div className="overflow-y-auto flex-1 max-h-[400px]">
        <table className="w-full text-left border-collapse">
          <thead className="sticky top-0 bg-slate-800/90 backdrop-blur-sm z-10">
            <tr>
              <th className="p-3 text-xs uppercase font-bold text-slate-500 border-b border-slate-700">Asset</th>
              <th className="p-3 text-xs uppercase font-bold text-slate-500 border-b border-slate-700">Event</th>
              <th className="p-3 text-xs uppercase font-bold text-slate-500 border-b border-slate-700">Link</th>
            </tr>
          </thead>
          <tbody>
            {data.length > 0 ? (
              data.map((item) => (
                <tr key={item.id} className="hover:bg-slate-700/30 transition-colors border-b border-slate-800/50">
                  <td className="p-3">
                    <div className="flex flex-col">
                      <span className="mono font-bold text-blue-400 text-sm">{item.symbol}</span>
                      <span className="text-[9px] text-slate-500">
                        {new Date(item.timestamp).toLocaleDateString()}
                      </span>
                    </div>
                  </td>
                  <td className="p-3">
                    <p className="text-xs text-slate-300 line-clamp-2">{item.title}</p>
                  </td>
                  <td className="p-3">
                    <a 
                      href={item.url} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-slate-500 hover:text-blue-400 transition-colors"
                      title="View Source"
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                      </svg>
                    </a>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={3} className="p-10 text-center text-slate-600 italic text-sm">No signals detected</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default DataTable;
