
import React from 'react';
import { 
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend
} from 'recharts';
import { ListingEntry } from '../types';

interface Props {
  data: ListingEntry[];
}

const Charts: React.FC<Props> = ({ data }) => {
  // Aggregate data for chart: Group by date (simplified to last 24 hours/days)
  const processChartData = () => {
    const counts: Record<string, any> = {};
    
    // Last 7 days aggregation (simplified)
    data.forEach(item => {
      const dateStr = new Date(item.timestamp).toLocaleDateString();
      if (!counts[dateStr]) {
        counts[dateStr] = { date: dateStr, CMC: 0, MEXC: 0, OURBIT: 0 };
      }
      if (item.source.includes('CMC')) counts[dateStr].CMC++;
      if (item.source.includes('MEXC')) counts[dateStr].MEXC++;
      if (item.source.includes('OURBIT')) counts[dateStr].OURBIT++;
    });

    return Object.values(counts).sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  };

  const chartData = processChartData();

  return (
    <div className="bg-slate-800/40 border border-slate-700/50 rounded-xl p-6 shadow-sm">
      <div className="mb-6">
        <h3 className="text-lg font-bold text-slate-200">Listing Trends</h3>
        <p className="text-sm text-slate-500">Activity volume across monitored platforms</p>
      </div>
      
      <div className="h-[300px] w-full">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={chartData}>
            <defs>
              <linearGradient id="colorCmc" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
              </linearGradient>
              <linearGradient id="colorMexc" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.3}/>
                <stop offset="95%" stopColor="#06b6d4" stopOpacity={0}/>
              </linearGradient>
              <linearGradient id="colorOurbit" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#a855f7" stopOpacity={0.3}/>
                <stop offset="95%" stopColor="#a855f7" stopOpacity={0}/>
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
            <XAxis dataKey="date" stroke="#64748b" fontSize={10} tickMargin={10} />
            <YAxis stroke="#64748b" fontSize={10} />
            <Tooltip 
              contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '8px' }}
              itemStyle={{ fontSize: '12px' }}
            />
            <Legend wrapperStyle={{ paddingTop: '20px' }} />
            <Area 
              type="monotone" 
              dataKey="CMC" 
              stroke="#3b82f6" 
              fillOpacity={1} 
              fill="url(#colorCmc)" 
              name="CMC Signals"
            />
            <Area 
              type="monotone" 
              dataKey="MEXC" 
              stroke="#06b6d4" 
              fillOpacity={1} 
              fill="url(#colorMexc)" 
              name="MEXC Listings"
            />
            <Area 
              type="monotone" 
              dataKey="OURBIT" 
              stroke="#a855f7" 
              fillOpacity={1} 
              fill="url(#colorOurbit)" 
              name="Ourbit Listings"
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default Charts;
