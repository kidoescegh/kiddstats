
import { GoogleGenAI, Type } from "@google/genai";
import { DataSource, ListingEntry } from "../types";

// Note: process.env.API_KEY is handled by the platform environment
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

// CMC API Key provided by user
const CMC_API_KEY = '141234c09b9d4da5b8921dd2c1ba328f';

const PARSE_SCHEMA = {
  type: Type.ARRAY,
  items: {
    type: Type.OBJECT,
    properties: {
      title: { type: Type.STRING, description: "The descriptive title of the listing or signal" },
      symbol: { type: Type.STRING, description: "The ticker symbol, e.g., BTC, PEPE" },
      timestamp: { type: Type.STRING, description: "ISO 8601 timestamp or date string from the text" },
      type: { type: Type.STRING, description: "The category of the announcement" },
      url: { type: Type.STRING, description: "Relevant URL for the announcement" }
    },
    required: ["title", "symbol", "timestamp"]
  }
};

/**
 * Uses Gemini 3 Pro with Google Search tool to fetch real-time listing data 
 * from the specific URLs provided, bypassing CORS and providing fresh intelligence.
 */
export async function parseSourceContent(source: DataSource): Promise<ListingEntry[]> {
  const sourceUrls = {
    [DataSource.CMC_SIGNALS]: "https://dex.coinmarketcap.com/signals/all/",
    [DataSource.OURBIT_LISTINGS]: "https://www.ourbit.com/support/sections/15425930840735",
    [DataSource.MEXC_LISTINGS]: "https://www.mexc.com/en-GB/announcements/new-listings"
  };

  const url = sourceUrls[source];
  const prompt = `Perform a Google Search to find the latest cryptocurrency listings and signals from this specific URL: ${url}. 
  If this is CoinMarketCap, focus on Dex signals. If MEXC or Ourbit, focus on "New Listings" announcements.
  Extract the most recent entries from the last 24-48 hours. 
  Output valid JSON matching the schema.`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }],
        responseMimeType: "application/json",
        responseSchema: PARSE_SCHEMA,
      },
    });

    const parsed: any[] = JSON.parse(response.text || "[]");
    
    // Extract grounding URLs for reference
    const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
    const sourceLink = groundingChunks[0]?.web?.uri || url;

    return parsed.map((item, idx) => ({
      ...item,
      id: `${source}-${Date.now()}-${idx}`,
      source,
      url: item.url || sourceLink,
      timestamp: item.timestamp || new Date().toISOString()
    }));
  } catch (error) {
    console.error(`Gemini Intelligence Error for ${source}:`, error);
    return [];
  }
}

/**
 * This function is now deprecated in favor of direct Gemini Search Grounding 
 * which handles the 'fetching' part more effectively for these specific URLs.
 */
export async function fetchExternalData(source: DataSource): Promise<string> {
  // In a real environment with the provided CMC_API_KEY, 
  // one would normally fetch from 'pro-api.coinmarketcap.com'.
  // However, for this dashboard's specific signal/listing requirements, 
  // we rely on the search-grounded parsing above.
  return "Data provided by Gemini Search Intelligence";
}
