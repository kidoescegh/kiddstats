
import { DataSource, ListingEntry } from "../types";

const DB_KEY = "crypto_sentinel_db";

export const storageService = {
  getAll: (): ListingEntry[] => {
    const data = localStorage.getItem(DB_KEY);
    return data ? JSON.parse(data) : [];
  },

  saveBatch: (entries: ListingEntry[]) => {
    const existing = storageService.getAll();
    // Simple de-duplication based on title + source
    const newEntries = entries.filter(e => 
      !existing.some(old => old.title === e.title && old.source === e.source)
    );
    
    if (newEntries.length === 0) return 0;

    const updated = [...newEntries, ...existing].sort((a, b) => 
      new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    );
    
    localStorage.setItem(DB_KEY, JSON.stringify(updated.slice(0, 1000))); // Keep last 1k records
    return newEntries.length;
  },

  getStatsBySource: () => {
    const all = storageService.getAll();
    return {
      [DataSource.CMC_SIGNALS]: all.filter(e => e.source === DataSource.CMC_SIGNALS).length,
      [DataSource.OURBIT_LISTINGS]: all.filter(e => e.source === DataSource.OURBIT_LISTINGS).length,
      [DataSource.MEXC_LISTINGS]: all.filter(e => e.source === DataSource.MEXC_LISTINGS).length,
    };
  }
};
